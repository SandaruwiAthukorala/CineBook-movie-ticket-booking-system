<?php
declare(strict_types=1);

// Update these values if your MySQL username, password, or database name differs.
define('DB_HOST', 'localhost');
define('DB_NAME', 'movie_ticket_booking');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_NAME', 'CineBook');

date_default_timezone_set('Asia/Colombo');
